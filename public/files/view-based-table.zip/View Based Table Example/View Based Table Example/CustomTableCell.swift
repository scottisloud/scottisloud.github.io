//
//  CustomTableCell.swift
//  View Based Table Example
//
//  Created by Scott Lougheed on 2020/02/26.
//  Copyright © 2020 Scott Lougheed. All rights reserved.
//

import Cocoa

class CustomTableCell: NSTableCellView {
    
    @IBOutlet weak var userNameLabel: NSTextField!
    @IBOutlet weak var roleLabel: NSTextField!
    
    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)

        // Drawing code here.
    }
    
    @IBAction func emailButton(_ sender: Any) {
        // Email user
    }
}
